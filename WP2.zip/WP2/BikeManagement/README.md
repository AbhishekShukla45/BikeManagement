# Bike-Management-System-Project-in-PHP

For User :-

USERNAME : test@gmail.com

PASSWORD : Test@12345

For Admin Panel

Open Your browser put inside browser “http://localhost/bikerental/admin”

USERNAME : admin

PASSWORD : Test@12345

DON'T FORGET TO CREATE A DATABASE NAMING "bikerental.sql" AND IMPORT THE SQL FILE AND RUN.
WITHOUT THE DATABASE THE PROJECT WON'T RUN.
